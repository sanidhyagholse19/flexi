import React, { useState } from 'react';
import { api } from './services/api';

const Services = () => {
  const [apiEndpoint, setApiEndpoint] = useState('/getall');
  const [apiResponse, setApiResponse] = useState(null);
  const [testingApi, setTestingApi] = useState(false);
  const [exportMessage, setExportMessage] = useState('');

  // Test API endpoint live
  const handleTestApi = async () => {
    try {
      setTestingApi(true);
      setApiResponse(null);
      let data;
      if (apiEndpoint === '/getall') {
        data = await api.getAllStudents();
      } else if (apiEndpoint === '/api/health') {
        data = await api.getHealth();
      } else {
        const res = await fetch(`http://localhost:5000${apiEndpoint}`);
        data = await res.json();
      }
      setApiResponse({ status: 200, data });
    } catch (err) {
      setApiResponse({ status: 'Error', error: err.message });
    } finally {
      setTestingApi(false);
    }
  };

  // Export to JSON
  const handleExportJson = async () => {
    try {
      const students = await api.getAllStudents();
      const blob = new Blob([JSON.stringify(students, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `SIT_SecB_Students_${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      setExportMessage('Exported students successfully as JSON!');
      setTimeout(() => setExportMessage(''), 4000);
    } catch (err) {
      setExportMessage(`Export failed: ${err.message}`);
    }
  };

  // Export to CSV
  const handleExportCsv = async () => {
    try {
      const students = await api.getAllStudents();
      if (!students || students.length === 0) {
        setExportMessage('No student records to export.');
        return;
      }
      const headers = ['MongoDB_ID', 'Name', 'Email', 'Age', 'Status'];
      const rows = students.map((s) => [
        s._id,
        `"${s.name}"`,
        `"${s.email}"`,
        s.age,
        `"${s.status}"`
      ]);
      const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `SIT_SecB_Students_${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      setExportMessage('Exported roster successfully as CSV!');
      setTimeout(() => setExportMessage(''), 4000);
    } catch (err) {
      setExportMessage(`Export failed: ${err.message}`);
    }
  };

  return (
    <div className="page-container">
      {/* Title */}
      <div style={{ textAlign: 'center', maxWidth: '760px', margin: '0 auto 48px auto' }}>
        <div className="hero-badge" style={{ background: '#dcfce7', color: '#15803d', border: 'none' }}>
          ⚡ Academic Portal Services
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '16px' }}>
          Database & Student Services
        </h1>
        <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)' }}>
          High-performance academic data management tools, live MongoDB querying, and reporting services.
        </p>
      </div>

      {exportMessage && (
        <div style={{ padding: '14px 20px', borderRadius: '10px', background: '#ecfdf5', color: '#065f46', marginBottom: '24px', fontWeight: 600 }}>
          {exportMessage}
        </div>
      )}

      {/* Services Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px', marginBottom: '48px' }}>
        {/* Service 1 */}
        <div className="sit-card" style={{ padding: '32px' }}>
          <div style={{ fontSize: '2rem', marginBottom: '16px' }}>📋</div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '10px' }}>
            Roster & Record Export
          </h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '20px' }}>
            Download real-time student collections directly from MongoDB Compass into JSON or formatted CSV spreadsheet files.
          </p>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button onClick={handleExportJson} className="btn-sit btn-sit-primary btn-sit-sm">
              📥 Export JSON
            </button>
            <button onClick={handleExportCsv} className="btn-sit btn-sit-secondary btn-sit-sm">
              📊 Export CSV
            </button>
          </div>
        </div>

        {/* Service 2 */}
        <div className="sit-card" style={{ padding: '32px' }}>
          <div style={{ fontSize: '2rem', marginBottom: '16px' }}>🛡️</div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '10px' }}>
            JWT Verification & Security
          </h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '20px' }}>
            Cryptographic token generation with bcrypt salt hashing. Guarantees confidentiality of student passwords and records.
          </p>
          <span className="badge-status active">HS256 Encrypted</span>
        </div>

        {/* Service 3 */}
        <div className="sit-card" style={{ padding: '32px' }}>
          <div style={{ fontSize: '2rem', marginBottom: '16px' }}>🔄</div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '10px' }}>
            MongoDB Compass Sync
          </h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '20px' }}>
            Instant two-way synchronization between the Express server and MongoDB Compass GUI on <code>mongodb://localhost:27017</code>.
          </p>
          <span className="badge-status graduated">Real-time WiredTiger</span>
        </div>
      </div>

      {/* Interactive API Tester Tool */}
      <div className="sit-card" style={{ padding: '36px', marginBottom: '40px' }}>
        <h3 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '10px' }}>
          🛠️ Live API Endpoint Tester
        </h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '20px' }}>
          Verify the sir's Express endpoints directly from this interactive console:
        </p>

        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '20px' }}>
          <select
            className="filter-select"
            value={apiEndpoint}
            onChange={(e) => setApiEndpoint(e.target.value)}
            style={{ flex: 1, minWidth: '220px' }}
          >
            <option value="/getall">GET /getall (Retrieve all students)</option>
            <option value="/api/health">GET /api/health (System & Mongo status)</option>
          </select>

          <button
            onClick={handleTestApi}
            disabled={testingApi}
            className="btn-sit btn-sit-primary"
          >
            {testingApi ? 'Executing...' : 'Run Query'}
          </button>
        </div>

        {apiResponse && (
          <div style={{ background: '#0f172a', color: '#38bdf8', borderRadius: '12px', padding: '20px', overflowX: 'auto', maxHeight: '350px' }}>
            <div style={{ color: '#94a3b8', fontSize: '0.8rem', marginBottom: '10px' }}>
              HTTP Status: <strong>{apiResponse.status}</strong>
            </div>
            <pre style={{ margin: 0, fontFamily: 'var(--font-mono)', fontSize: '0.82rem', color: '#f8fafc' }}>
              {JSON.stringify(apiResponse.data || apiResponse.error, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default Services;
