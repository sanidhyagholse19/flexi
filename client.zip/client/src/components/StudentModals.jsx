import React, { useState } from 'react';

// 1. Add Student Modal
export const AddStudentModal = ({ isOpen, onClose, onSave, loading }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    age: '21',
    status: 'Active',
    password: ''
  });
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.password.trim()) {
      setError('Please fill in Name, Email, and Password');
      return;
    }
    setError('');
    onSave(formData);
  };

  return (
    <div className="modal-backdrop-custom" onClick={onClose}>
      <div className="modal-dialog-custom" onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 700, margin: 0 }}>Enroll New Student</h3>
            <p style={{ margin: 0, fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              Inserts document into MongoDB collection <code>student</code>
            </p>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: 'var(--text-muted)' }}>&times;</button>
        </div>

        <form onSubmit={handleSubmit} style={{ padding: '24px' }}>
          {error && (
            <div style={{ padding: '10px 14px', borderRadius: '8px', background: '#fef2f2', color: '#991b1b', marginBottom: '16px', fontSize: '0.85rem' }}>
              {error}
            </div>
          )}

          <div className="form-group-custom">
            <label className="form-label-custom">Full Name</label>
            <input
              type="text"
              className="form-control-custom"
              placeholder="e.g. Somesh Sharma"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="form-group-custom">
            <label className="form-label-custom">Email Address</label>
            <input
              type="email"
              className="form-control-custom"
              placeholder="e.g. somesh@sit.edu"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            <div className="form-group-custom">
              <label className="form-label-custom">Age</label>
              <input
                type="number"
                min="16"
                max="80"
                className="form-control-custom"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                required
              />
            </div>

            <div className="form-group-custom">
              <label className="form-label-custom">Status</label>
              <select
                className="form-control-custom"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Graduated">Graduated</option>
                <option value="Suspended">Suspended</option>
              </select>
            </div>
          </div>

          <div className="form-group-custom">
            <label className="form-label-custom">Password (Hashed with Bcrypt)</label>
            <input
              type="password"
              className="form-control-custom"
              placeholder="Min 6 characters"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
            />
            <small style={{ color: 'var(--text-light)', fontSize: '0.75rem', marginTop: '4px', display: 'block' }}>
              Password will be securely encrypted via bcrypt before saving to MongoDB.
            </small>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '24px' }}>
            <button type="button" onClick={onClose} className="btn-sit btn-sit-secondary">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="btn-sit btn-sit-primary">
              {loading ? 'Creating...' : 'Enroll Student'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 2. Edit Student Modal
export const EditStudentModal = ({ isOpen, student, onClose, onSave, loading }) => {
  const [status, setStatus] = useState(student?.status || 'Active');
  const [name, setName] = useState(student?.name || '');
  const [age, setAge] = useState(student?.age || 20);
  const [email, setEmail] = useState(student?.email || '');

  React.useEffect(() => {
    if (student) {
      setStatus(student.status || 'Active');
      setName(student.name || '');
      setAge(student.age || 20);
      setEmail(student.email || '');
    }
  }, [student]);

  if (!isOpen || !student) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(student._id, { status, name, age: Number(age), email });
  };

  return (
    <div className="modal-backdrop-custom" onClick={onClose}>
      <div className="modal-dialog-custom" onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 700, margin: 0 }}>Update Student Record</h3>
            <p style={{ margin: 0, fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              MongoDB ObjectId: <code>{String(student._id)}</code>
            </p>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: 'var(--text-muted)' }}>&times;</button>
        </div>

        <form onSubmit={handleSubmit} style={{ padding: '24px' }}>
          <div className="form-group-custom">
            <label className="form-label-custom">Full Name</label>
            <input
              type="text"
              className="form-control-custom"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="form-group-custom">
            <label className="form-label-custom">Email</label>
            <input
              type="email"
              className="form-control-custom"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            <div className="form-group-custom">
              <label className="form-label-custom">Age</label>
              <input
                type="number"
                min="16"
                max="80"
                className="form-control-custom"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                required
              />
            </div>

            <div className="form-group-custom">
              <label className="form-label-custom">Status</label>
              <select
                className="form-control-custom"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Graduated">Graduated</option>
                <option value="Suspended">Suspended</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '24px' }}>
            <button type="button" onClick={onClose} className="btn-sit btn-sit-secondary">
              Cancel
            </button>
            <button type="submit" disabled={loading} className="btn-sit btn-sit-primary">
              {loading ? 'Saving...' : 'Update Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 3. View Student Details Modal
export const ViewStudentModal = ({ isOpen, student, onClose }) => {
  if (!isOpen || !student) return null;

  return (
    <div className="modal-backdrop-custom" onClick={onClose}>
      <div className="modal-dialog-custom" onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '24px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, margin: 0 }}>Student Profile Details</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: 'var(--text-muted)' }}>&times;</button>
        </div>

        <div style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px' }}>
            <div
              style={{
                width: '64px',
                height: '64px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #4f46e5, #06b6d4)',
                color: '#fff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.8rem',
                fontWeight: 800
              }}
            >
              {student.name ? student.name[0].toUpperCase() : 'S'}
            </div>
            <div>
              <h2 style={{ fontSize: '1.4rem', fontWeight: 800, margin: '0 0 4px 0' }}>{student.name}</h2>
              <span className={`badge-status ${student.status?.toLowerCase() || 'active'}`}>
                {student.status || 'Active'}
              </span>
            </div>
          </div>

          <div style={{ background: '#f8fafc', borderRadius: '12px', padding: '16px', border: '1px solid var(--border-color)' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', rowGap: '12px', fontSize: '0.9rem' }}>
              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>MongoDB _id:</span>
              <code>{String(student._id)}</code>

              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>Email:</span>
              <span>{student.email}</span>

              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>Age:</span>
              <span>{student.age} years old</span>

              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>Role / Status:</span>
              <span>{student.status}</span>

              <span style={{ color: 'var(--text-muted)', fontWeight: 600 }}>Enrolled:</span>
              <span>{student.createdAt ? new Date(student.createdAt).toLocaleDateString() : 'Active Term'}</span>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '24px' }}>
            <button onClick={onClose} className="btn-sit btn-sit-secondary">
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// 4. Delete Confirmation Modal
export const DeleteConfirmModal = ({ isOpen, student, onClose, onConfirm, loading }) => {
  if (!isOpen || !student) return null;

  return (
    <div className="modal-backdrop-custom" onClick={onClose}>
      <div className="modal-dialog-custom" onClick={(e) => e.stopPropagation()}>
        <div style={{ padding: '24px' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '12px', textAlign: 'center' }}>⚠️</div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800, textAlign: 'center', marginBottom: '8px' }}>
            Confirm Deletion
          </h3>
          <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '24px' }}>
            Are you sure you want to delete student <strong>{student.name}</strong> ({student.email})?
            This will permanently remove the record from MongoDB collection <code>student</code>.
          </p>

          <div style={{ display: 'flex', justifyContent: 'center', gap: '12px' }}>
            <button onClick={onClose} className="btn-sit btn-sit-secondary">
              Cancel
            </button>
            <button
              onClick={() => onConfirm(student._id)}
              disabled={loading}
              className="btn-sit btn-sit-danger"
            >
              {loading ? 'Deleting...' : 'Yes, Delete Student'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
