import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import './App.css';

const Nav = () => {
  const location = useLocation();
  const { user, isAuthenticated, logout, mongoStatus } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="my-nav">
      <div className="nav-container">
        {/* Brand */}
        <Link to="/" className="nav-brand">
          <div className="nav-brand-icon">🎓</div>
          <div>
            <div>SIT Sec-B</div>
            <div style={{ fontSize: '0.68rem', fontWeight: 500, color: 'var(--text-muted)' }}>
              Student Information Portal
            </div>
          </div>
        </Link>

        {/* Navigation Links */}
        <ul className="nav-links-list">
          <li className="nav-link-item">
            <Link to="/" className={isActive('/') ? 'active' : ''}>
              Home
            </Link>
          </li>
          <li className="nav-link-item">
            <Link to="/about" className={isActive('/about') ? 'active' : ''}>
              About
            </Link>
          </li>
          <li className="nav-link-item">
            <Link to="/services" className={isActive('/services') ? 'active' : ''}>
              Services
            </Link>
          </li>
          <li className="nav-link-item">
            <Link to="/contact" className={isActive('/contact') ? 'active' : ''}>
              Contact!
            </Link>
          </li>
        </ul>

        {/* Right side items: MongoDB Pill + Auth */}
        <div className="nav-actions">
          {/* MongoDB Connection Status */}
          <div
            className={`mongo-status-pill ${mongoStatus.connected ? 'connected' : 'disconnected'}`}
            title={
              mongoStatus.connected
                ? `Connected to MongoDB (${mongoStatus.database}.${mongoStatus.collection})`
                : 'MongoDB offline / Standalone demo mode'
            }
          >
            <span className="pulse-dot"></span>
            <span>
              {mongoStatus.connected ? 'MongoDB Live' : 'Demo Mode'}
            </span>
          </div>

          {/* User / Auth State */}
          {isAuthenticated && user ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, #4f46e5, #06b6d4)',
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 700,
                    fontSize: '0.85rem'
                  }}
                >
                  {user.name ? user.name[0].toUpperCase() : 'U'}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', textAlign: 'left' }}>
                  <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-main)' }}>
                    {user.name}
                  </span>
                  <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                    {user.status || 'Student'}
                  </span>
                </div>
              </div>
              <button
                onClick={logout}
                className="btn-sit btn-sit-secondary btn-sit-sm"
                title="Sign out"
              >
                Logout
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Link to="/login" className="btn-sit btn-sit-secondary btn-sit-sm">
                Login
              </Link>
              <Link to="/register" className="btn-sit btn-sit-primary btn-sit-sm">
                Register
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Nav;
