import React, { useState } from 'react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    prn: '',
    category: 'Academic Query',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="page-container">
      {/* Title */}
      <div style={{ textAlign: 'center', maxWidth: '760px', margin: '0 auto 48px auto' }}>
        <div className="hero-badge" style={{ background: '#fef3c7', color: '#b45309', border: 'none' }}>
          📬 Helpdesk & Academic Queries
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '16px' }}>
          Contact Academic Support
        </h1>
        <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)' }}>
          Have questions regarding CA-03 enrollment, MongoDB collection synchronization, or student records?
          Reach out to the SIT Section-B lab coordinators.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '36px', marginBottom: '48px' }}>
        {/* Contact Form */}
        <div className="sit-card" style={{ padding: '36px' }}>
          <h3 style={{ fontSize: '1.35rem', fontWeight: 700, marginBottom: '6px' }}>
            Submit an Inquiry
          </h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', marginBottom: '24px' }}>
            Fill out the details below. Our technical coordinator will get back to you.
          </p>

          {submitted ? (
            <div style={{ padding: '32px 20px', textAlign: 'center', background: '#f0fdf4', borderRadius: '12px', border: '1px solid #bbf7d0' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>🎉</div>
              <h4 style={{ fontWeight: 700, color: '#166534', marginBottom: '6px' }}>Message Received!</h4>
              <p style={{ color: '#15803d', fontSize: '0.9rem', marginBottom: '16px' }}>
                Thank you, <strong>{formData.name}</strong>. Your query has been logged under reference #{Math.floor(100000 + Math.random() * 900000)}.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setFormData({ name: '', email: '', prn: '', category: 'Academic Query', message: '' });
                }}
                className="btn-sit btn-sit-secondary btn-sit-sm"
              >
                Send Another Inquiry
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="form-group-custom">
                <label className="form-label-custom">Full Name</label>
                <input
                  type="text"
                  className="form-control-custom"
                  placeholder="e.g. Rahul Sharma"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="form-group-custom">
                <label className="form-label-custom">Student Email</label>
                <input
                  type="email"
                  className="form-control-custom"
                  placeholder="e.g. rahul.sharma@sit.edu"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                <div className="form-group-custom">
                  <label className="form-label-custom">PRN / Roll Number</label>
                  <input
                    type="text"
                    className="form-control-custom"
                    placeholder="25070521060"
                    value={formData.prn}
                    onChange={(e) => setFormData({ ...formData, prn: e.target.value })}
                  />
                </div>

                <div className="form-group-custom">
                  <label className="form-label-custom">Category</label>
                  <select
                    className="form-control-custom"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  >
                    <option value="Academic Query">Academic Query</option>
                    <option value="MongoDB Issue">MongoDB Issue</option>
                    <option value="CA-03 Submission">CA-03 Submission</option>
                    <option value="Account Login">Account Login</option>
                  </select>
                </div>
              </div>

              <div className="form-group-custom">
                <label className="form-label-custom">Message</label>
                <textarea
                  className="form-control-custom"
                  rows="4"
                  placeholder="Describe your issue or inquiry in detail..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                ></textarea>
              </div>

              <button type="submit" className="btn-sit btn-sit-primary" style={{ width: '100%' }}>
                Send Message
              </button>
            </form>
          )}
        </div>

        {/* Contact Info & Department Cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div className="sit-card" style={{ padding: '28px' }}>
            <h4 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '12px' }}>
              📍 Symbiosis Institute of Technology
            </h4>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', lineHeight: '1.6', margin: 0 }}>
              Department of Computer Science & Engineering<br />
              Section B - Web Technologies Lab<br />
              Lavale, Pune, Maharashtra 412115
            </p>
          </div>

          <div className="sit-card" style={{ padding: '28px' }}>
            <h4 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '12px' }}>
              👨‍🏫 Faculty Coordinator
            </h4>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', lineHeight: '1.6', margin: 0 }}>
              <strong>Prof. Somesh Chutel</strong><br />
              Email: <code>somesh.chutel@sit.edu</code><br />
              GitHub: <code>github.com/somesh-chutel</code><br />
              Office Hours: Monday - Friday, 2:00 PM - 5:00 PM
            </p>
          </div>

          <div className="sit-card" style={{ padding: '28px' }}>
            <h4 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '12px' }}>
              ⚡ Tech Support Checklist
            </h4>
            <ul style={{ paddingLeft: '20px', color: 'var(--text-muted)', fontSize: '0.85rem', lineHeight: '1.7' }}>
              <li>Ensure <code>mongod.exe</code> is running on <code>127.0.0.1:27017</code></li>
              <li>Verify Express backend is running on <code>http://localhost:5000</code></li>
              <li>Inspect <code>sitSecB</code> database via MongoDB Compass GUI</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
