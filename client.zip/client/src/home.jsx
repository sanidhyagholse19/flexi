import React, { useState, useEffect, useCallback } from 'react';
import Header from './homeComp/header';
import MainContentCont from './homeComp/mainContentCont';
import { AddStudentModal, EditStudentModal, ViewStudentModal, DeleteConfirmModal } from './components/StudentModals';
import { api } from './services/api';
import { useAuth } from './context/AuthContext';
import './App.css';

const Home = () => {
  const { mongoStatus, checkMongoHealth } = useAuth();
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [viewMode, setViewMode] = useState('table'); // 'table' or 'grid'

  // Modals state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  // Toast notification state
  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Fetch all students (Sir's route: /getall)
  const loadStudents = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getAllStudents();
      setStudents(Array.isArray(data) ? data : []);
      checkMongoHealth();
    } catch (err) {
      console.error('Failed to load students:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [checkMongoHealth]);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  // Handle Add Student
  const handleAddStudent = async (formData) => {
    try {
      setActionLoading(true);
      await api.createStudent(formData);
      showToast(`Student ${formData.name} added successfully!`, 'success');
      setIsAddOpen(false);
      loadStudents();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Handle Update Student
  const handleUpdateStudent = async (id, updatedFields) => {
    try {
      setActionLoading(true);
      await api.updateStudent(id, updatedFields);
      showToast('Student record updated successfully!', 'success');
      setIsEditOpen(false);
      loadStudents();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Handle Delete Student
  const handleDeleteStudent = async (id) => {
    try {
      setActionLoading(true);
      await api.deleteStudent(id);
      showToast('Student deleted successfully', 'success');
      setIsDeleteOpen(false);
      loadStudents();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Handle Seed Data
  const handleSeedData = async () => {
    try {
      setActionLoading(true);
      await api.seedStudents();
      showToast('Sample students seeded successfully!', 'success');
      loadStudents();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Filter students
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      (s.name || '').toLowerCase().includes(search.toLowerCase()) ||
      (s.email || '').toLowerCase().includes(search.toLowerCase());
    const matchesStatus =
      statusFilter === 'ALL' || (s.status || '').toUpperCase() === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="page-container">
      {/* Toast Banner */}
      {toast && (
        <div className={`toast-banner ${toast.type}`}>
          <span>{toast.type === 'success' ? '✅' : '❌'}</span>
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header & Hero */}
      <Header
        totalStudents={students.length}
        activeCount={students.filter((s) => s.status?.toLowerCase() === 'active').length}
        onOpenAddModal={() => setIsAddOpen(true)}
        onSeedData={handleSeedData}
        loading={actionLoading}
      />

      {/* MongoDB Status Warning Banner (if offline) */}
      {!mongoStatus.connected && (
        <div
          style={{
            background: '#fffbeb',
            border: '1px solid #fde68a',
            borderRadius: '12px',
            padding: '16px 20px',
            marginBottom: '28px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '16px',
            flexWrap: 'wrap'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ fontSize: '1.4rem' }}>💡</span>
            <div>
              <strong style={{ color: '#92400e', fontSize: '0.95rem' }}>
                MongoDB Compass / Server Connection Notice
              </strong>
              <div style={{ color: '#b45309', fontSize: '0.85rem' }}>
                Currently running in responsive Demo Mode. Start MongoDB Compass or run{' '}
                <code>mongod</code> on port 27017 to synchronize directly with database{' '}
                <code>sitSecB</code>.
              </div>
            </div>
          </div>
          <button
            onClick={checkMongoHealth}
            className="btn-sit btn-sit-sm"
            style={{ background: '#fef3c7', color: '#92400e', border: '1px solid #fcd34d' }}
          >
            Retry Connection
          </button>
        </div>
      )}

      {/* Stats Counter Cards */}
      <MainContentCont students={students} />

      {/* Filter and Control Bar */}
      <div className="filter-bar">
        <div className="search-input-group">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            className="search-input"
            placeholder="Search students by name or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <select
            className="filter-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
            <option value="GRADUATED">Graduated</option>
            <option value="SUSPENDED">Suspended</option>
          </select>

          {/* View Toggle */}
          <div style={{ display: 'flex', background: '#f1f5f9', borderRadius: '8px', padding: '3px' }}>
            <button
              onClick={() => setViewMode('table')}
              style={{
                border: 'none',
                background: viewMode === 'table' ? '#ffffff' : 'transparent',
                padding: '6px 12px',
                borderRadius: '6px',
                fontSize: '0.85rem',
                fontWeight: 600,
                cursor: 'pointer',
                boxShadow: viewMode === 'table' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none'
              }}
            >
              📋 Table
            </button>
            <button
              onClick={() => setViewMode('grid')}
              style={{
                border: 'none',
                background: viewMode === 'grid' ? '#ffffff' : 'transparent',
                padding: '6px 12px',
                borderRadius: '6px',
                fontSize: '0.85rem',
                fontWeight: 600,
                cursor: 'pointer',
                boxShadow: viewMode === 'grid' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none'
              }}
            >
              🗂️ Cards
            </button>
          </div>

          <button
            onClick={() => setIsAddOpen(true)}
            className="btn-sit btn-sit-primary btn-sit-sm"
          >
            <span>➕</span> Add Student
          </button>
        </div>
      </div>

      {/* Main Student Records Section */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '60px 20px', background: '#fff', borderRadius: '12px', border: '1px solid var(--border-color)' }}>
          <div style={{ fontSize: '2rem', marginBottom: '12px' }}>🔄</div>
          <h4 style={{ fontWeight: 600, color: 'var(--text-muted)' }}>
            Retrieving student records from MongoDB...
          </h4>
        </div>
      ) : filteredStudents.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 20px', background: '#fff', borderRadius: '12px', border: '1px solid var(--border-color)' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>📂</div>
          <h3 style={{ fontWeight: 700, marginBottom: '6px' }}>No student records found</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '20px' }}>
            {search || statusFilter !== 'ALL'
              ? 'Try adjusting your search query or status filter.'
              : 'Your MongoDB collection is empty. Seed initial student records to get started.'}
          </p>
          <button onClick={handleSeedData} className="btn-sit btn-sit-primary">
            Seed Sample Students
          </button>
        </div>
      ) : viewMode === 'table' ? (
        /* TABLE VIEW */
        <div className="table-responsive-custom">
          <table className="student-table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Age</th>
                <th>Status</th>
                <th>Email</th>
                <th>MongoDB ID</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.map((s) => (
                <tr key={s._id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div className="student-avatar">
                        {s.name ? s.name[0].toUpperCase() : 'S'}
                      </div>
                      <div>
                        <div style={{ fontWeight: 700, color: 'var(--text-main)' }}>{s.name}</div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-light)' }}>
                          {s.createdAt ? new Date(s.createdAt).toLocaleDateString() : 'Term 2026'}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td>{s.age}</td>
                  <td>
                    <span className={`badge-status ${s.status?.toLowerCase() || 'active'}`}>
                      {s.status || 'Active'}
                    </span>
                  </td>
                  <td>
                    <span style={{ color: 'var(--text-muted)' }}>{s.email}</span>
                  </td>
                  <td>
                    <code style={{ fontSize: '0.75rem', background: '#f1f5f9', padding: '3px 6px', borderRadius: '4px' }}>
                      {String(s._id).slice(0, 8)}...
                    </code>
                  </td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '8px' }}>
                      <button
                        onClick={() => {
                          setSelectedStudent(s);
                          setIsViewOpen(true);
                        }}
                        className="btn-sit btn-sit-secondary btn-sit-sm"
                        title="View Details"
                      >
                        👁️
                      </button>
                      <button
                        onClick={() => {
                          setSelectedStudent(s);
                          setIsEditOpen(true);
                        }}
                        className="btn-sit btn-sit-secondary btn-sit-sm"
                        title="Edit Record"
                      >
                        ✏️
                      </button>
                      <button
                        onClick={() => {
                          setSelectedStudent(s);
                          setIsDeleteOpen(true);
                        }}
                        className="btn-sit btn-sit-danger btn-sit-sm"
                        title="Delete Student"
                      >
                        🗑️
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* CARD GRID VIEW */
        <div className="student-grid">
          {filteredStudents.map((s) => (
            <div key={s._id} className="student-card-item">
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div className="student-avatar" style={{ width: '44px', height: '44px', fontSize: '1.1rem' }}>
                      {s.name ? s.name[0].toUpperCase() : 'S'}
                    </div>
                    <div>
                      <h4 style={{ margin: 0, fontWeight: 700, fontSize: '1.05rem' }}>{s.name}</h4>
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{s.email}</span>
                    </div>
                  </div>
                  <span className={`badge-status ${s.status?.toLowerCase() || 'active'}`}>
                    {s.status || 'Active'}
                  </span>
                </div>

                <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', fontSize: '0.82rem', marginBottom: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Age:</span>
                    <strong>{s.age} yrs</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--text-muted)' }}>MongoDB ID:</span>
                    <code>{String(s._id).slice(-8)}</code>
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '8px', borderTop: '1px solid var(--border-color)', paddingTop: '14px' }}>
                <button
                  onClick={() => {
                    setSelectedStudent(s);
                    setIsViewOpen(true);
                  }}
                  className="btn-sit btn-sit-secondary btn-sit-sm"
                  style={{ flex: 1 }}
                >
                  View
                </button>
                <button
                  onClick={() => {
                    setSelectedStudent(s);
                    setIsEditOpen(true);
                  }}
                  className="btn-sit btn-sit-secondary btn-sit-sm"
                  style={{ flex: 1 }}
                >
                  Edit
                </button>
                <button
                  onClick={() => {
                    setSelectedStudent(s);
                    setIsDeleteOpen(true);
                  }}
                  className="btn-sit btn-sit-danger btn-sit-sm"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modals */}
      <AddStudentModal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        onSave={handleAddStudent}
        loading={actionLoading}
      />

      <EditStudentModal
        isOpen={isEditOpen}
        student={selectedStudent}
        onClose={() => setIsEditOpen(false)}
        onSave={handleUpdateStudent}
        loading={actionLoading}
      />

      <ViewStudentModal
        isOpen={isViewOpen}
        student={selectedStudent}
        onClose={() => setIsViewOpen(false)}
      />

      <DeleteConfirmModal
        isOpen={isDeleteOpen}
        student={selectedStudent}
        onClose={() => setIsDeleteOpen(false)}
        onConfirm={handleDeleteStudent}
        loading={actionLoading}
      />
    </div>
  );
};

export default Home;
