import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from './context/AuthContext';

const About = () => {
  const { mongoStatus } = useAuth();

  return (
    <div className="page-container">
      {/* Title */}
      <div style={{ textAlign: 'center', maxWidth: '760px', margin: '0 auto 48px auto' }}>
        <div className="hero-badge" style={{ background: '#e0e7ff', color: '#4338ca', border: 'none' }}>
          📖 Continuous Assessment 03 (CA-03)
        </div>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, letterSpacing: '-0.02em', marginBottom: '16px' }}>
          About SIT Sec-B Student Portal
        </h1>
        <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)' }}>
          A full-stack modern web application demonstrating RESTful APIs, MongoDB database persistence,
          JWT authentication, and responsive user experience.
        </p>
      </div>

      {/* Grid: 3 Main Pillars */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px', marginBottom: '48px' }}>
        <div className="sit-card" style={{ padding: '32px' }}>
          <div style={{ fontSize: '2rem', marginBottom: '16px' }}>🍃</div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '10px' }}>MongoDB & Compass</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: '1.6' }}>
            Powered by MongoDB Server 9.0 and managed through MongoDB Compass.
            Data is stored in database <code>{mongoStatus.database || 'sitSecB'}</code> within collection <code>student</code> with native ObjectId identifiers.
          </p>
        </div>

        <div className="sit-card" style={{ padding: '32px' }}>
          <div style={{ fontSize: '2rem', marginBottom: '16px' }}>⚙️</div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '10px' }}>Express.js REST API</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: '1.6' }}>
            Node.js backend with Express 5, implementing CRUD operations: <code>/getall</code>, <code>/get/:id</code>, <code>/create</code>, <code>/update/:id</code>, and <code>/delete/:id</code> with enabled CORS and body parsing.
          </p>
        </div>

        <div className="sit-card" style={{ padding: '32px' }}>
          <div style={{ fontSize: '2rem', marginBottom: '16px' }}>🔐</div>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '10px' }}>Security & Auth</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.92rem', lineHeight: '1.6' }}>
            Password encryption using <strong>bcrypt</strong> with 10 salt rounds before persisting to database, and session authentication through <strong>JSON Web Tokens (JWT)</strong>.
          </p>
        </div>
      </div>

      {/* Architecture Deep Dive */}
      <div className="sit-card" style={{ padding: '40px', marginBottom: '48px' }}>
        <h2 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '24px' }}>
          System Architecture & Data Flow
        </h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px' }}>
          <div style={{ background: '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)' }}>
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--primary)', textTransform: 'uppercase' }}>Step 1: Client</span>
            <h4 style={{ margin: '8px 0', fontWeight: 700 }}>React 19 & Vite</h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: 0 }}>
              User submits student information via clean forms. Requests are sent asynchronously via Axios/Fetch API with JWT tokens.
            </p>
          </div>

          <div style={{ background: '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)' }}>
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#0ea5e9', textTransform: 'uppercase' }}>Step 2: Server</span>
            <h4 style={{ margin: '8px 0', fontWeight: 700 }}>Express Server</h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: 0 }}>
              Validates payloads, hashes passwords via bcrypt, generates JWT tokens, and interfaces with the official MongoDB driver.
            </p>
          </div>

          <div style={{ background: '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid var(--border-color)' }}>
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#10b981', textTransform: 'uppercase' }}>Step 3: Database</span>
            <h4 style={{ margin: '8px 0', fontWeight: 700 }}>MongoDB <code>sitSecB</code></h4>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: 0 }}>
              Documents are persisted into the <code>student</code> collection. Data is inspectable in real-time through MongoDB Compass GUI.
            </p>
          </div>
        </div>
      </div>

      {/* Course & Mentor Credits */}
      <div style={{ background: 'linear-gradient(135deg, #1e1b4b, #312e81)', borderRadius: '16px', padding: '36px', color: '#ffffff', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '20px' }}>
        <div>
          <h3 style={{ fontSize: '1.4rem', fontWeight: 800, margin: '0 0 8px 0', color: '#fff' }}>
            Faculty Mentor: Prof. Somesh Chutel
          </h3>
          <p style={{ margin: 0, color: '#c7d2fe', fontSize: '0.95rem' }}>
            Continuous Assessment 03 (CA-03) | Symbiosis Institute of Technology (SIT) - Section B
          </p>
        </div>
        <Link to="/" className="btn-sit btn-sit-accent">
          Go To Live Dashboard
        </Link>
      </div>
    </div>
  );
};

export default About;
