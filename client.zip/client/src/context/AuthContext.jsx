import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { api } from "../services/api";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("sit_student_user");
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState(() => localStorage.getItem("sit_student_token") || null);
  const [mongoStatus, setMongoStatus] = useState({
    connected: false,
    checked: false,
    database: "sitSecB",
    collection: "student"
  });

  const checkMongoHealth = useCallback(async () => {
    try {
      const data = await api.getHealth();
      setMongoStatus({
        connected: data.mongoConnected,
        checked: true,
        database: data.database || "sitSecB",
        collection: data.collection || "student"
      });
    } catch {
      setMongoStatus((prev) => ({ ...prev, connected: false, checked: true }));
    }
  }, []);

  useEffect(() => {
    checkMongoHealth();
    const interval = setInterval(checkMongoHealth, 15000); // Check every 15s
    return () => clearInterval(interval);
  }, [checkMongoHealth]);

  const login = async (email, password) => {
    const res = await api.login({ email, password });
    if (res.jwtToken) {
      setToken(res.jwtToken);
      localStorage.setItem("sit_student_token", res.jwtToken);
      const studentUser = res.user || { email, name: email.split("@")[0] };
      setUser(studentUser);
      localStorage.setItem("sit_student_user", JSON.stringify(studentUser));
      return { success: true, user: studentUser };
    }
    return { success: false, msg: res.msg || "Authentication failed" };
  };

  const register = async (studentData) => {
    const res = await api.createStudent(studentData);
    return res;
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("sit_student_token");
    localStorage.removeItem("sit_student_user");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!token,
        mongoStatus,
        checkMongoHealth,
        login,
        register,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
