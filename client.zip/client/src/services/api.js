// Centralized API Service for SIT Sec-B Student Portal

const API_BASE = "http://localhost:5000";

// Helper for fetch with fallback to proxy
async function request(path, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {})
  };

  // Attach JWT token if present in localStorage
  const token = localStorage.getItem("sit_student_token");
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const fetchOptions = {
    ...options,
    headers
  };

  try {
    // First try via proxy / relative path
    const res = await fetch(path, fetchOptions);
    return res;
  } catch (primaryErr) {
    // Fallback to direct localhost:5000 if proxy isn't active
    try {
      const directUrl = `${API_BASE}${path.startsWith('/') ? path : '/' + path}`;
      const res = await fetch(directUrl, fetchOptions);
      return res;
    } catch (fallbackErr) {
      throw new Error(`API connection failed: ${fallbackErr.message}`);
    }
  }
}

export const api = {
  // 1. Fetch all students (Sir's route: /getall)
  async getAllStudents() {
    const res = await request("/getall");
    if (!res.ok) throw new Error(`Failed to fetch students: ${res.statusText}`);
    return res.json();
  },

  // 2. Fetch single student by id (Sir's route: /get/:id)
  async getStudentById(id) {
    const res = await request(`/get/${id}`);
    if (!res.ok) throw new Error(`Student not found: ${res.statusText}`);
    return res.json();
  },

  // 3. Create / Register student (Sir's route: /create)
  async createStudent(studentData) {
    const res = await request("/create", {
      method: "POST",
      body: JSON.stringify(studentData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.msg || "Failed to create student");
    return data;
  },

  // 4. Login student (Sir's route: /login)
  async login(credentials) {
    const res = await request("/login", {
      method: "POST",
      body: JSON.stringify(credentials)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.msg || "Login failed");
    return data;
  },

  // 5. Update student status/info (Sir's route: /update/:id)
  async updateStudent(id, updateData) {
    const res = await request(`/update/${id}`, {
      method: "PUT",
      body: JSON.stringify(updateData)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.msg || "Failed to update student");
    return data;
  },

  // 6. Delete student (Sir's route: /delete/:id)
  async deleteStudent(id) {
    const res = await request(`/delete/${id}`, {
      method: "DELETE"
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.msg || "Failed to delete student");
    return data;
  },

  // System Health / MongoDB Status
  async getHealth() {
    try {
      const res = await request("/api/health");
      if (!res.ok) return { mongoConnected: false, status: "error" };
      return res.json();
    } catch {
      return { mongoConnected: false, status: "offline" };
    }
  },

  // Seed sample students
  async seedStudents() {
    const res = await request("/api/seed", { method: "POST" });
    return res.json();
  }
};
