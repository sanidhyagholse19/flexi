import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="portal-footer">
      <div className="footer-content">
        {/* Col 1: About SIT Sec B */}
        <div className="footer-col">
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '14px' }}>
            <span style={{ fontSize: '1.5rem' }}>🎓</span>
            <span style={{ fontSize: '1.2rem', fontWeight: 800, color: '#ffffff' }}>
              SIT Sec-B Student Portal
            </span>
          </div>
          <p style={{ fontSize: '0.88rem', lineHeight: '1.6', color: '#94a3b8', maxWidth: '380px' }}>
            Symbiosis Institute of Technology (SIT) - Continuous Assessment (CA-03) Full-Stack Web Application.
            Demonstrating end-to-end CRUD operations, bcrypt password encryption, and JWT token authentication with MongoDB.
          </p>
        </div>

        {/* Col 2: Navigation Links */}
        <div className="footer-col">
          <h4>Navigation</h4>
          <ul className="footer-links">
            <li><Link to="/">Home & Dashboard</Link></li>
            <li><Link to="/about">About Architecture</Link></li>
            <li><Link to="/services">Portal Services</Link></li>
            <li><Link to="/contact">Contact Support</Link></li>
          </ul>
        </div>

        {/* Col 3: Tech Stack */}
        <div className="footer-col">
          <h4>Technology Stack</h4>
          <ul className="footer-links">
            <li><span style={{ color: '#cbd5e1' }}>MongoDB Server 9.0</span></li>
            <li><span style={{ color: '#cbd5e1' }}>Express.js 5.2</span></li>
            <li><span style={{ color: '#cbd5e1' }}>React 19 & Vite 8</span></li>
            <li><span style={{ color: '#cbd5e1' }}>Bcrypt & JWT Auth</span></li>
          </ul>
        </div>

        {/* Col 4: Faculty & Lab */}
        <div className="footer-col">
          <h4>Academic Credits</h4>
          <ul className="footer-links">
            <li><span style={{ color: '#cbd5e1' }}>Course: Web Technologies</span></li>
            <li><span style={{ color: '#cbd5e1' }}>Assessment: CA-03</span></li>
            <li><span style={{ color: '#cbd5e1' }}>Faculty: Somesh Chutel</span></li>
            <li><span style={{ color: '#cbd5e1' }}>Section: SIT Sec-B</span></li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <div>
          &copy; {new Date().getFullYear()} SIT Sec-B Academic Portal. All Rights Reserved. Built for Continuous Assessment.
        </div>
        <div style={{ display: 'flex', gap: '16px' }}>
          <span>Database: <code>sitSecB.student</code></span>
          <span>Port: <code>5000 / 5173</code></span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
