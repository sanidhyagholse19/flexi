import React from 'react';
import { useAuth } from '../context/AuthContext';

const Header = ({ totalStudents, activeCount, onOpenAddModal, onSeedData, loading }) => {
  const { mongoStatus } = useAuth();

  return (
    <div className="hero-wrapper">
      <div className="hero-badge">
        <span>⚡</span> CA-03 Full-Stack Database Integration
      </div>

      <h1 className="hero-title">
        SIT Section-B <span>Student Portal</span>
      </h1>

      <p className="hero-subtitle">
        Getting student data from local server connected with MongoDB Compass & MongoDB Server.
        Perform real-time CRUD operations, manage student enrollment records, and test JWT authenticated workflows.
      </p>

      <div className="hero-cta-group">
        <button
          onClick={onOpenAddModal}
          className="btn-sit btn-sit-accent"
          style={{ padding: '12px 24px', fontSize: '0.95rem' }}
        >
          <span>➕</span> Add New Student
        </button>

        <button
          onClick={onSeedData}
          disabled={loading}
          className="btn-sit btn-sit-secondary"
          style={{ padding: '12px 20px', fontSize: '0.95rem', background: 'rgba(255,255,255,0.15)', color: '#fff', border: '1px solid rgba(255,255,255,0.3)' }}
        >
          <span>🔄</span> {loading ? 'Syncing...' : 'Reset / Seed Sample Data'}
        </button>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.85rem', color: '#cbd5e1' }}>
          <span>Database:</span>
          <code style={{ background: 'rgba(0,0,0,0.3)', padding: '4px 8px', borderRadius: '4px', color: '#38bdf8' }}>
            {mongoStatus.database || 'sitSecB'}.student
          </code>
        </div>
      </div>
    </div>
  );
};

export default Header;
