import React from 'react';

const MainContentCont = ({ students = [] }) => {
  const total = students.length;
  const active = students.filter(s => s.status?.toLowerCase() === 'active').length;
  const graduated = students.filter(s => s.status?.toLowerCase() === 'graduated').length;
  const inactive = students.filter(s => ['inactive', 'suspended'].includes(s.status?.toLowerCase())).length;

  const avgAge = total > 0
    ? Math.round(students.reduce((acc, curr) => acc + (Number(curr.age) || 0), 0) / total)
    : 0;

  return (
    <div className="stats-grid">
      <div className="stat-card">
        <div className="stat-icon blue">👨‍🎓</div>
        <div>
          <div className="stat-val">{total}</div>
          <div className="stat-label">Total Enrolled</div>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon green">✅</div>
        <div>
          <div className="stat-val">{active}</div>
          <div className="stat-label">Active Students</div>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon purple">🎓</div>
        <div>
          <div className="stat-val">{graduated}</div>
          <div className="stat-label">Graduated</div>
        </div>
      </div>

      <div className="stat-card">
        <div className="stat-icon amber">📊</div>
        <div>
          <div className="stat-val">{avgAge || 21} <span style={{ fontSize: '1rem', fontWeight: 500 }}>yrs</span></div>
          <div className="stat-label">Average Age</div>
        </div>
      </div>
    </div>
  );
};

export default MainContentCont;
