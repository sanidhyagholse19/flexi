import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/getall': 'http://localhost:5000',
      '/get': 'http://localhost:5000',
      '/create': 'http://localhost:5000',
      '/login': 'http://localhost:5000',
      '/update': 'http://localhost:5000',
      '/delete': 'http://localhost:5000',
      '/api': 'http://localhost:5000'
    }
  }
})
